import { StyleSheet } from 'react-native';


const ponstyle = StyleSheet.create({
    mainView: {
        backgroundColor: '#DEE6E1',
        flex: 1
    },
    Scrollview: {
        alignSelf: 'center',
        // marginTop:12,
        // width:'95%',
        margin: '3%',
        marginBottom: '5%',
        flex: 1,
        // marginBottom:10,
        backgroundColor: '#FFFFFF',
    },
    bottomView: {
        flex: 0.1
    },
    locationView: {
        flexDirection: 'row',
        paddingTop: "3%"
    },
    loc_code_view: {
        flexDirection: 'column',
        width: "25%",
        marginStart: "4%",
    },
    loc_code_text: {
        color: '#11246F',
        fontWeight: 'bold'
    },
    loc_code_no: {
        fontWeight: 'bold',
        alignSelf: 'center'
    },
    offn_views: {
        backgroundColor: "#000000",
        width: "0.4%",
        height: "100%",
        marginStart: "2%",
    },
    offn_view: {
        flexDirection: 'column',
        flex: 0,
        width: "30%",
        marginStart: "2%"
    },

    offr_name: {
        color: '#000000',
        padding: "4%"
    },
    main_view_status: {
        flex: 1,
        height: 60

    },
    view_status: {
        backgroundColor: '#DEE6E1',
        height: 4,
        width: '50%',
        alignSelf: 'center',
        marginTop: "6%"
    },

    first_status: {
        backgroundColor: '#30D20D',
        color: 'white',
        borderRadius: 60 / 2,
        height: 20,
        width: "5.5%",
        textAlign: 'center',
        marginStart: "23%",
        bottom: "20%"
    },
    sec_status: {
        backgroundColor: '#DEE6E1',
        color: 'white',
        borderRadius: 60 / 2,
        height: 20,
        width: "5.5%",
        textAlign: 'center',
        alignSelf: 'center',
        bottom: "55%"
    },
    third_status: {
        backgroundColor: '#DEE6E1',
        color: 'white',
        borderRadius: 60 / 2,
        height: 20,
        width: "5.5%",
        textAlign: 'center',
        bottom: "86%",
        alignSelf: 'flex-end',
        marginRight: "24%"
    },



    info_txt: {
        color: '#11246F',
        bottom: "80%",
        start: '23%',
        fontSize: 12
    },
    offn_txt: {
        color: '#11246F',
        bottom: "105%",
        alignSelf: 'center',
        fontSize: 12
    },
    review_txt: {
        color: '#11246F',
        bottom: "130%",
        start: '68%',
        fontSize: 12
    },

    flash_view: {
        flexDirection: 'row',
        height: 55,
        marginTop: "2%",
        marginStart: "5%",
        marginEnd: "5%"
    },
    sdl_txt: {
        color: '#11246F',
        marginTop: '5%'
    },
    flash_txt: {
        marginTop: '5%',
        color: '#11246F'
    },
    scan_btn: {
        borderWidth: 1.2,
        borderColor: '#11246F',
        borderRadius: 9,
        height: '80%',
        width: 110,
        alignSelf: 'center',
        marginStart: "2%"
    },
    scan_txt: {
        color: '#11246F',
        textAlign: 'left',
        marginTop: "10%",
        marginStart: "4%",
        position: 'absolute',
        width: '50%'
    },
    scan_img: {
        height: '100%',
        width: '40%',
        alignSelf: 'flex-end'
    },

    main_text_view: {
        flexDirection: 'row',
        height: 55,
        flex: 1,
        marginTop: "1%",
        marginStart: "3%",
        marginEnd: "3%",
        bottom: "1%",
    },

    inputTextStyleTwo: {
        width: '46%',
        backgroundColor: '#ffffff',
        marginLeft: "2%",
        fontSize: 12
    },

    inputTextStyleThree: {
        width: '30%',
        backgroundColor: '#ffffff',
        marginLeft: "2%",
        fontSize: 12

    },

    gend_view: {
        width: '50%',
        marginLeft: "2%",
        flexDirection: 'column',
        marginTop: "3%"

    },
    sex_txt: {
        fontSize: 12,
        color: '#11246F'
    },
    sec_gend_view: {
        flexDirection: 'row'

    },
    nxt_btn: {
        backgroundColor: '#30D20D',
        alignSelf: 'flex-end',
        width: '30%',
        marginEnd: "4%",
        marginTop: "10%",
        borderRadius: 10,
        marginBottom: '2%'
    },


})

export default ponstyle;