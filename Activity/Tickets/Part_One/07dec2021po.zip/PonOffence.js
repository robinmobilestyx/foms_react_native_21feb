import React, { Component } from 'react';
import { SafeAreaView, StyleSheet, View, Image, Text, LogBox, TouchableOpacity, FlatList, Alert, Keyboard } from 'react-native';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import CheckBox from 'react-native-checkbox-animated';
import { ScrollView, } from 'react-native-gesture-handler';
import { RadioButton, TextInput, Button } from 'react-native-paper';
import checkIn from '../../assets/checkin.png';
import prevsLocation from '../../assets/prs_location.png';
import Global_Attributes from '../../../Utility/Global_Attributes';
// import Geolocation from '@react-native-community/geolocation';
import { request, PERMISSIONS, RESULTS, check } from 'react-native-permissions';
import ModalDropdown from 'react-native-modal-dropdown';
import Modal from 'react-native-modals';
import Autocomplete from "react-native-autocomplete-input";
import LawsController from '../../Controller/LawsController';
import Dropdownarrow from '../../assets/downarrow.png';
import Viewdetails from '../../assets/cloud4.png';
import SearchIcon from '../../assets/search.png';
import DropDownPicker from 'react-native-dropdown-picker';
import Geolocation from 'react-native-geolocation-service';
import Geocoder from 'react-native-geocoder';
import DashboardFooter from '../../Dashboard/DashboardFooter';
import AsyncStorage from '@react-native-async-storage/async-storage';
import TicketsModulesApi from '../../Controller/TicketsModulesApi';
import LawsSearch from '../../Laws/LawsSearch';
import ponsoffnStyle from '../../Css/ponOffenseStyle';
// import SearchableDropdown from 'react-native-searchable-dropdown';



const PLATEFORM_LOCATION_PERMISSION = {
    ios: PERMISSIONS.IOS.LOCATION_ALWAYS,
    android: PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION,
}
const REQUEST_PERMISSION_TYPE = {
    location: PLATEFORM_LOCATION_PERMISSION,
}

const PERMISSION_TYPE = {
    location: 'location',
}



export default class PonOffence extends Component {
    constructor(props) {
        super(props)
        this.next = this.next.bind(this);
        this.getLocation = this.getLocation.bind(this);
        this.prevLocation = this.prevLocation.bind(this);
        this.back = this.back.bind(this);
        this.state = {
            motorInvolved: Global_Attributes.PonOneBean['motorInvolved'],
            collision: Global_Attributes.PonOneBean['collision'],
            withnesses: Global_Attributes.PonOneBean['withnesses'],
            atOne: Global_Attributes.PonOneBean['atOne'],
            atTwo: Global_Attributes.PonOneBean['atTwo'],
            atThree: Global_Attributes.PonOneBean['atThree'],
            atFour: Global_Attributes.PonOneBean['atFour'],
            atFive: Global_Attributes.PonOneBean['atFive'],
            manualLocation: Global_Attributes.PonOneBean['manualLocation'],
            didCommit: Global_Attributes.PonOneBean['didCommit'],
            contrary: Global_Attributes.PonOneBean['contrary'],
            sect: Global_Attributes.PonOneBean['sect'],
            plateNumber: Global_Attributes.PonOneBean['plateNumber'],
            juris: Global_Attributes.PonOneBean['juris'],
            commercial: Global_Attributes.PonOneBean['commercial'],
            cvor: Global_Attributes.PonOneBean['cvor'],
            nsc: Global_Attributes.PonOneBean['nsc'],
            code: Global_Attributes.PonOneBean['code'],
            fine: Global_Attributes.PonOneBean['fine'],
            payable: Global_Attributes.PonOneBean['payable'],
            covrNumer: Global_Attributes.PonOneBean['covrNumer'],
            km_over: Global_Attributes.PonOneBean['km_over'],
            schedule: Global_Attributes.PonOneBean['schedule'],
            schld2Rb: Global_Attributes.PonOneBean['schld2Rb'],
            comunitySafZone: Global_Attributes.PonOneBean['communitysafeZone'],
            constZOne: Global_Attributes.PonOneBean['constZOne'],
            speedLimit: Global_Attributes.PonOneBean['speedLimit'],
            chargedSpeed: Global_Attributes.PonOneBean['chargedSpeed'],
            speedActual: Global_Attributes.PonOneBean['speedActual'],
            speedingCb: Global_Attributes.PonOneBean['speedingCb'],

            issuedDate: Global_Attributes.PonOneBean['issuedDate'],
            concent: false,
            acttitlevalue: '',
            actnovalue: '',
            ApiUrl: 'https://mdei.info/police_app_v1/api/laws/law',
            check: '',
            keyboardStatus: 'Keyboard Hidden',
            // query: "",
            // query1:"",
            act_title: '',
            setFine: '',
            totalPayable: '',
            AT: '',
            NEAR: '',
            attextinputvalue: '',
            neartextinputvalue: '',
            open: false,
            value: null,
            items: null,
            atmodalVisible: false,
            nearmodalVisible: false,
            ATfocus: false,
            NEARfocus: false,
        }


    }

    back = () => {
        this.props.navigation.navigate('PonInfo');
    }
    getLocation = () => {

        this.checkPermission(PERMISSION_TYPE.location)

            .catch(error => alert("your error is:" + error));
        Geolocation.getCurrentPosition(
            (position) => {
                console.log("latitude:" + position.coords.latitude);
                console.log("longitude:" + position.coords.longitude);
                Global_Attributes.PonOneBean['lat'] = position.coords.latitude;
                Global_Attributes.PonOneBean['long'] = position.coords.longitude;
                this.setState({ lat: position.coords.latitude })
                this.setState({ lon: position.coords.longitude })

                var pos = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };

                Geocoder.geocodePosition(pos).then(res => {
                    console.log(res[0]);
                    const pinCode = (res[0].pincode);
                    Global_Attributes.gpsAddress['gpsPincode'] = pinCode;
                    let loc = (res[0].locality);
                    Global_Attributes.gpsAddress['gpsCity'] = loc;
                    if (loc != null) {
                        console.log("city:" + loc.toUpperCase());
                        this.setState({ atThree: loc.toUpperCase() });

                    }

                    let Streen_name = (res[0].streetName);
                    if (Streen_name != null) {
                        console.log("street name:" + Streen_name.toUpperCase());
                        this.setState({ attextinputvalue: Streen_name.toUpperCase() });
                    }


                    let state = (res[0].adminArea);
                    this.setState({ states: state });
                    console.log("State:" + state);
                    Global_Attributes.gpsAddress['gpsState'] = state;

                    let subA = (res[0].subAdminArea);
                    this.setState({ district: res[0].subAdminArea });
                    console.log("district:" + subA);
                    Global_Attributes.gpsAddress['gpsDistrict'] = subA

                })
                    .catch(error => console.log("your error is:" + error));
            },
            (error) => {
                // See error code charts below.
                console.log(error.code, error.message);
            },
            { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
        );
    }

    checkPermission = async (type) => {
        const permission = REQUEST_PERMISSION_TYPE[type][Platform.OS];
        console.log(permission)
        if (!permission) {
            return true;
        }
        try {
            const result = await check(permission)
            console.log("permission check ", result)
            if (result === RESULTS.GRANTED) {
                // Geolocation.setRNConfiguration(config); 
                // Geolocation.getCurrentPosition(info => console.log("geolocation:"+info['country']));
                return true;
            }

            return this.requestPermission(permission);

        }
        catch (error) {

            console.log(error);
        }
    }
    requestPermission = async (permission) => {
        try {
            const result = await request(permission)
            console.log("permission request", result)
            Geolocation.getCurrentPosition(info => console.log("geolocation:" + info));
            return result === RESULTS.GRANTED;
        }
        catch (error) {
            console.log("App permission result fail " + error)
            return false;
        }

    }
    // componentDidMount(){
    //     this.checkPermission(PERMISSION_TYPE.location)
    //     }
    checkBoxChanged() {
        this.setState({ concent: !this.state.concent })
    }
    sppeedigCheckBoxChanged() {
        this.setState({ speedingCb: !this.state.speedingCb })
    }
    motorCheckBoxChanged() {
        this.setState({ motorInvolved: !this.state.motorInvolved })
    }
    collisionCheckBoxChanged() {
        this.setState({ collision: !this.state.collision })
    }
    WitnesCheckBoxChanged() {
        this.setState({ withnesses: !this.state.withnesses })
    }
    CvorCheckBoxChanged() {
        this.setState({ cvor: !this.state.cvor })
    }
    NscCheckBoxChanged() {
        this.setState({ nsc: !this.state.nsc })
    }
    commercialCheckBoxChanged() {
        this.setState({ commercial: !this.state.commercial })
    }
    setBeans = () => {
        Global_Attributes.PonOneBean['motorInvolved'] = this.state.motorInvolved;
        Global_Attributes.PonOneBean['withnesses'] = this.state.withnesses;
        Global_Attributes.PonOneBean['atTwo'] = this.state.neartextinputvalue;
        Global_Attributes.PonOneBean['atOne'] = this.state.attextinputvalue;
        Global_Attributes.PonOneBean['collision'] = this.state.collision;
        Global_Attributes.PonOneBean['atThree'] = this.state.atThree;
        Global_Attributes.PonOneBean['atFour'] = this.state.atFour;
        Global_Attributes.PonOneBean['atFive'] = this.state.atFive;
        Global_Attributes.PonOneBean['manualLocation'] = this.state.manualLocation;
        Global_Attributes.PonOneBean['didCommit'] = this.state.didCommit;
        Global_Attributes.PonOneBean['contrary'] = Global_Attributes.PonLaws['parent_law'][0];
        Global_Attributes.PonOneBean['sect'] = this.state.sect;
        Global_Attributes.PonOneBean['plateNumber'] = this.state.plateNumber;
        Global_Attributes.PonOneBean['juris'] = this.state.juris;
        Global_Attributes.PonOneBean['commercial'] = this.state.commercial;
        Global_Attributes.PonOneBean['cvor'] = this.state.cvor;
        Global_Attributes.PonOneBean['nsc'] = this.state.nsc;
        Global_Attributes.PonOneBean['code'] = this.state.code;
        Global_Attributes.PonOneBean['fine'] = this.state.fine;
        Global_Attributes.PonOneBean['payable'] = this.state.payable;
        Global_Attributes.PonOneBean['covrNumer'] = this.state.covrNumer;
        Global_Attributes.PonOneBean['km_over'] = this.state.km_over;
        Global_Attributes.PonOneBean['schedule'] = this.state.schedule;
        Global_Attributes.PonOneBean['speedLimit'] = this.state.speedLimit;
        Global_Attributes.PonOneBean['chargedSpeed'] = this.state.chargedSpeed;
        Global_Attributes.PonOneBean['speedActual'] = this.state.speedActual;
        Global_Attributes.PonOneBean['speedingCb'] = this.state.speedingCb;
        Global_Attributes.PonOneBean['schld2Rb'] = this.state.schld2Rb;
        Global_Attributes.PonOneBean['issuedDate'] = this.state.issuedDate;
        this.props.navigation.navigate('PonPreview')
        console.log("chckbox value" + Global_Attributes.PonOneBean['motorInvolved']);
    }

    componentDidMount() {
        this.timing();
        this.keyboardDidShowSubscription = Keyboard.addListener(
            'keyboardDidShow',
            () => {
                this.setState({ keyboardStatus: 'Keyboard Shown' });
            },
        );
        this.keyboardDidHideSubscription = Keyboard.addListener(
            'keyboardDidHide',
            () => {
                this.setState({ keyboardStatus: 'Keyboard Hidden' });
                this.setState({ nearmodalVisible: false, atmodalVisible: false, });
                // this._keyboardDidHide
            },
        );
        LogBox.ignoreLogs(['VirtualizedLists should never be nested']);
        LogBox.ignoreLogs(['Encountered two children with the same key']);
        this.fetchLawsTitle(Global_Attributes.PonLaws['parent_law_id'][0]);
        // this.keyboardDidHideListener = Keyboard.addListener('keyboardDidHide',this._keyboardDidHide);
    }
    _keyboardDidHide = () => {
        this.setState({ nearmodalVisible: false, atmodalVisible: false, });
    }
    componentWillUnmount() {
        this.keyboardDidShowSubscription.remove();
        this.keyboardDidHideSubscription.remove();
        Global_Attributes.PonOffencePayable = '';
        Global_Attributes.PonffenceFine = '';
    }
    fetchLawsTitle = (id) => {
        // console.log(id)
        var user = Global_Attributes.User;
        var pass = Global_Attributes.Pass;

        let All_acts = {
            user: user,
            pass: pass,
            id: id,
        }
        new LawsController().getAllActs(All_acts, this.props, "PonOffence", Global_Attributes.laws);

    }

    searchActs = (query, bool) => {
        if (bool) {
            if (query === "") {
                return [];
            }
            else {
                var acttitle = [];
                const Length = Global_Attributes.PonLaws['act_length'];
                for (let i = 0; i < Length; i++) {
                    acttitle[i] = Global_Attributes.PonLaws['act_title'][i];
                }
                const regex = new RegExp(`${query}`, "i");
                const act_title = acttitle.filter(data => data.search(regex) >= 0);
                return act_title
            }
        }
        else {
            if (query === "") {
                return [];
            }
            else {
                var actno = [];
                let actArray = [];
                const Length = Global_Attributes.PonLaws['act_length'];
                for (let i = 0; i < Length; i++) {
                    actno[i] = Global_Attributes.PonLaws['act_no'][i];
                }
                const regex = new RegExp(`${query}`, "i");
                const act_no = actno.filter(data => data.search(regex) >= 0);
                act_no.forEach(index => {
                    var i = (Global_Attributes.PonLaws['act_no']).indexOf(index);
                    actArray.push(Global_Attributes.PonLaws['act_no'][i] + " : " + Global_Attributes.PonLaws['act_title'][i]);
                })
                return actArray;
            }
        }

    }
    setAct = (item) => {
        var index = (Global_Attributes.PonLaws['act_title']).indexOf(item);
        this.setState({
            setFine: Global_Attributes.PonLaws['set_fine'][index],
            totalPayable: Global_Attributes.PonLaws['total_payable'][index]
        });
        return Global_Attributes.PonLaws['act_no'][index];
    }

    setActNo = (item) => {
        var sec_reg = item.match(/.*(?=\s:)/);
        var index = (Global_Attributes.PonLaws['act_no']).indexOf(sec_reg[0]);
        this.setState({
            setFine: Global_Attributes.PonLaws['set_fine'][index],
            totalPayable: Global_Attributes.PonLaws['total_payable'][index]
        });
        return Global_Attributes.PonLaws['act_title'][index];
    }

    lawDescription = (item) => {
        var sec_reg = item.match(/.*(?=\s:)/);
        var index = (Global_Attributes.PonLaws['act_no']).indexOf(sec_reg[0]);

        var actno = Global_Attributes.PonLaws['act_no'][index];
        var acttitle = Global_Attributes.PonLaws['act_title'][index];
        var setfine = Global_Attributes.PonLaws['set_fine'][index];
        var totalpayable = Global_Attributes.PonLaws['total_payable'][index];
        var description = Global_Attributes.PonLaws['act_des'][index];
        var demerits = Global_Attributes.PonLaws['demerits'][index];
        this.props.navigation.navigate("LawsDescription", {
            actno: actno,
            acttitle: acttitle,
            setfine: setfine,
            totalpayable: totalpayable,
            description: description,
            demerits: demerits
        })
    }

    AT = (searchvalue) => {
        if (searchvalue) {
            var user = Global_Attributes.User;
            var pass = Global_Attributes.Pass;

            let All_acts = {
                user: user,
                pass: pass,
                search_value: searchvalue,
            }
            new LawsController().getATvalues(All_acts, this.props, "AT", Global_Attributes.nearValues);
            this.setState({ AT: Global_Attributes.PonLaws['ATNEARvalues'], atmodalVisible: true, ATfocus: true });
        }
        else {
            this.setState({ AT: "", atmodalVisible: false, ATfocus: true });
        }
    }
    NEAR = (searchvalue) => {
        if (searchvalue) {
            var user = Global_Attributes.User;
            var pass = Global_Attributes.Pass;

            let All_acts = {
                user: user,
                pass: pass,
                search_value: searchvalue,
            }
            new LawsController().getATvalues(All_acts, this.props, "AT", Global_Attributes.nearValues);
            this.setState({ NEAR: Global_Attributes.PonLaws['ATNEARvalues'], nearmodalVisible: true, NEARfocus: true });
        }
        else {
            this.setState({ NEAR: "", nearmodalVisible: false, NEARfocus: true });
        }
    }

    timing() {
        setInterval(() => {
            this.setState({
                fine: Global_Attributes.PonffenceFine,
                payable: Global_Attributes.PonOffencePayable,
            })
        }, 1000);
    }
    setOpen(open) {
        this.setState({
            open
        });
    }
    setValue(callback) {
        this.setState(state => ({
            value: state
        }));
    }
    setItems(callback) {
        this.setState(state => ({
            items: state
        }));
    }
    emptyFields = () => {
        var fields = [];
        if (this.state.atTwo == "") {
            fields.push("2ND Street Name")
        }
        if (this.state.plateNumber.trim() == "") {
            fields.push("Plate Number")
        }


        return fields;
    }
    next = () => {

        if (this.state.attextinputvalue == "") {
            alert("Please check address !")
        }
        else if (Global_Attributes.PonOneBean['didCommit'] == "") {
            alert("Enter Did Commmit !")
        }
        else if (Global_Attributes.PonOneBean['sect'] == "") {
            alert("Enter Section !")
        }
        else if (!this.state.concent) {
            alert("Please Accept Terms And Conditions !")
        }
        else {
            if (this.emptyFields().length > 0) {
                Alert.alert("Notice", "The following field(s) are missing:\n\n" + this.emptyFields() + "\n\n Do you wish to continue?", [{ text: 'YES', onPress: () => { this.setBeans() } },
                {
                    text: "No",
                    onPress: () => console.log("Cancel Pressed"),
                    style: "cancel"
                }]);
            }
            else {
                this.setBeans()
            }

        }
    }
    prevLocation = async () => {
        const ticketId = await AsyncStorage.getItem('insertId');
        const uname = await AsyncStorage.getItem('userName');

        console.log('ticketId: ', ticketId);

        let ticketBody = {
            // user: 'TempUser',
            // pass: 'TempUserPass@1234',
            user: Global_Attributes.User,
            pass: Global_Attributes.Pass,
            ticket_no: ticketId,
            uname: uname,
        };

        new TicketsModulesApi().api_call(
            ticketBody,
            this.props,
            'prevLocation',
            Global_Attributes.prsLocation,
        );
    };

    render() {

        const { navigation } = this.props;
        const { didCommit, sect, keyboardStatus } = this.state;
        const act_title = this.searchActs(didCommit, true);
        const act_no = this.searchActs(sect, false);
        return (
            <SafeAreaView style={ponsoffnStyle.mainView}>
                <ScrollView scrollEnabled={true} style={ponsoffnStyle.Scrollview}>
                    <View>
                        <View style={ponsoffnStyle.locationView}>
                            <View style={ponsoffnStyle.main_view_loc}>
                                <Text style={ponsoffnStyle.loc_code_txt}>Location Code</Text>
                                <Text style={ponsoffnStyle.loc_code}>{Global_Attributes.PonOneBean['locationCode']}</Text>
                            </View>
                            <View style={ponsoffnStyle.sec_main_view}></View>
                            <View style={ponsoffnStyle.secc_main_view}>
                                <Text style={ponsoffnStyle.offn_no}>Offence Number</Text>
                                <Text style={ponsoffnStyle.loc_code}>{Global_Attributes.PonOneBean['formatted']}</Text>
                            </View>
                        </View>
                        <View style={ponsoffnStyle.offr_name_view}>
                            <Text style={ponsoffnStyle.offr_name}>Officer Name : {Global_Attributes.PonOneBean['officerName']}</Text>
                        </View>
                        <View style={ponsoffnStyle.main_view_status} >
                            <View style={ponsoffnStyle.view_status}></View>
                            <Text style={ponsoffnStyle.first_status}>1</Text>
                            <Text style={ponsoffnStyle.sec_status}>2</Text>
                            <Text style={ponsoffnStyle.third_status}>3</Text>
                            <Text style={ponsoffnStyle.info_txt}>Info</Text>
                            <Text style={ponsoffnStyle.offn_txt}>Offence</Text>
                            <Text style={ponsoffnStyle.review_txt}>Review</Text>
                        </View>
                        <View style={ponsoffnStyle.mv_view}>
                            <View style={ponsoffnStyle.mvi_view}>
                                <Text style={ponsoffnStyle.mvi_txt}>Motor Vehicle Involved</Text>
                                <View style={ponsoffnStyle.firstCheckbx}>
                                    <CheckBox
                                        checked={this.state.motorInvolved}
                                        // style={{ marginStart: 30, marginTop: 10 }}
                                        onValueChange={() => this.motorCheckBoxChanged()}
                                        unCheckedBorderColor={'#11246F'}
                                        checkedBackgroundColor={"#11246F"}
                                        checkedBorderColor={"#11246F"}
                                        borderWidth={2}
                                        checkMarkColor={'white'}
                                        checkMarkSize={18}
                                        animationType={'left'}
                                        size={18}
                                        rippleEffect={false}
                                        label="NO"
                                        labelStyle={{ color: '#11246e' }}
                                    ></CheckBox>
                                    {/* <Text style={{ paddingTop: "8%", color: 'darkblue' }}>No</Text> */}
                                </View>
                            </View>
                            <View style={ponsoffnStyle.cols_view} >
                                <Text style={ponsoffnStyle.colsn_txt}>Collision Involved</Text>
                                <View style={ponsoffnStyle.secCheckbx}>
                                    <CheckBox
                                        checked={this.state.collision}
                                        style={{ marginStart: 30, marginTop: 20 }}
                                        // checkBoxColor='#11246F'
                                        onValueChange={() => this.collisionCheckBoxChanged()}
                                        checkedBackgroundColor={"#11246F"}
                                        checkedBorderColor={"#11246F"}
                                        unCheckedBorderColor={'#11246F'}
                                        borderWidth={2}
                                        checkMarkColor={'white'}
                                        checkMarkSize={18}
                                        animationType={'left'}
                                        size={18}
                                        rippleEffect={false}
                                        label="YES"
                                        labelStyle={{ color: '#11246e' }}
                                    ></CheckBox>
                                    {/* <Text style={{ paddingTop: "8%", color: 'darkblue' }}>No</Text> */}
                                </View>
                            </View>
                            <View style={ponsoffnStyle.wittn_view}>
                                <Text style={ponsoffnStyle.colsn_txt}>Witnesses</Text>
                                <View style={ponsoffnStyle.thirdCheckbx}>
                                    <CheckBox
                                        checked={this.state.withnesses}
                                        style={{ marginStart: 30, marginTop: 10 }}
                                        checkBoxColor={'#11246F'}
                                        onValueChange={() => this.WitnesCheckBoxChanged()}
                                        checkedBackgroundColor={"#11246F"}
                                        checkedBorderColor='#11246F'
                                        borderWidth={2}
                                        unCheckedBorderColor={'#11246F'}
                                        checkMarkColor={'white'}
                                        checkMarkSize={18}
                                        animationType={'left'}
                                        size={18}
                                        rippleEffect={false}
                                        label="YES"
                                        labelStyle={{ color: '#11246e' }}
                                    ></CheckBox>
                                    {/* <Text style={{ paddingTop: "8%", color: 'darkblue' }}>No</Text> */}
                                </View>
                            </View>
                        </View>
                        <Modal
                            visible={this.state.atmodalVisible}
                            onTouchOutside={() => {
                                this.setState({ atmodalVisible: false, ATfocus: true });
                            }}
                            animationDuration={0}
                            onHardwareBackPress={() => { this.setState({ LawSectATfocusionfocus: true, atmodalVisible: false }) }}
                            onShow={() => { this.setState({ ATfocus: true }) }}
                            onModalHide={() => { this.setState({ ATfocus: true, atmodalVisible: false }) }}
                            overlayBackgroundColor=""
                            style={{ position: 'absolute', justifyContent: 'flex-end', bottom: hp("20&"), marginStart: "5%", }}
                            hasOverlay={false}
                        >
                            <View style={{
                                width: '100%',
                                maxHeight: "100%",
                                borderRadius: 0.5,
                                shadowColor: 'black',
                                backgroundColor: 'white',
                                elevation: 10,
                                marginLeft: 10, marginRight: 10, marginBottom: 10, marginTop: 10
                            }}>
                                <FlatList
                                    nestedScrollEnabled={true}
                                    keyboardShouldPersistTaps={'handled'}
                                    maxHeight={250}
                                    data={this.state.AT}
                                    renderItem={({ item }) => {
                                        return (
                                            <View style={{ flex: 1, borderBottomWidth: 0.5, borderColor: 'black', marginRight: 15, marginLeft: 15, alignSelf: 'stretch' }}>
                                                <TouchableOpacity
                                                    onPress={() => this.setState({ attextinputvalue: item, AT: '' })}
                                                >
                                                    <Text style={ponsoffnStyle.itemText}>{item}</Text>
                                                </TouchableOpacity>
                                            </View>
                                        );
                                    }}
                                    keyExtractor={(item) => item}
                                />
                            </View>
                        </Modal>


                        <Modal
                            visible={this.state.nearmodalVisible}
                            onTouchOutside={() => {
                                this.setState({ nearmodalVisible: false, NEARfocus: true });
                            }}
                            animationDuration={0}
                            onHardwareBackPress={() => { this.setState({ NEARfocus: true, nearmodalVisible: false }) }}
                            onShow={() => { this.setState({ NEARfocus: true }) }}
                            onModalHide={() => { this.setState({ NEARfocus: true, nearmodalVisible: false }) }}
                            overlayBackgroundColor=""
                            style={{ position: 'absolute', marginStart: "45%", justifyContent: 'flex-end', bottom: hp("20%") }}
                            hasOverlay={false}
                        >
                            <View style={{
                                width: '100%',
                                height: "100%",
                                borderRadius: 0.5,
                                shadowColor: 'black',
                                backgroundColor: 'white',
                                shadowOpacity: 100,
                                elevation: 10,
                            }}>
                                <FlatList
                                    nestedScrollEnabled={true}
                                    keyboardShouldPersistTaps={'handled'}
                                    maxHeight={250}
                                    data={this.state.NEAR}
                                    renderItem={({ item }) => {
                                        return (
                                            <View style={{ flex: 1, borderBottomWidth: 0.5, borderColor: 'black', marginRight: 15, marginLeft: 15, alignSelf: 'stretch' }}>
                                                <TouchableOpacity
                                                    onPress={() => this.setState({ neartextinputvalue: item, NEAR: '' })}
                                                >
                                                    <Text style={ponsoffnStyle.itemText}>{item}</Text>
                                                </TouchableOpacity>
                                            </View>
                                        );
                                    }}
                                    keyExtractor={(item) => item}
                                />
                            </View>
                        </Modal>


                        <View style={ponsoffnStyle.atNearView}>
                            <View style={ponsoffnStyle.main_text_views}>
                                <TextInput value={this.state.attextinputvalue}
                                    style={ponsoffnStyle.inputAT}
                                    onChangeText={(text) => this.setState({ attextinputvalue: this.AT(text) })}
                                    label='AT*' labelStyle={{ fontSize: 12 }} underlineColor={'#000000'}

                                />
                            </View>

                            <View style={ponsoffnStyle.main_text_views}>
                                <TextInput value={this.state.neartextinputvalue}
                                    style={ponsoffnStyle.inputAT}

                                    onChangeText={(text) => this.setState({ neartextinputvalue: this.NEAR(text) })}
                                    label='NEAR' labelStyle={{ fontSize: 12 }} underlineColor={'#000000'}
                                />
                            </View>
                        </View>

                        <View style={ponsoffnStyle.blankTextView}>
                            <View style={ponsoffnStyle.blankTextView1}>
                                <TextInput style={{ width: '96%', backgroundColor: '#ffffff', fontSize: 12, height:55 }}
                                    underlineColor={'#000000'} value={this.state.atThree}
                                    onChangeText={(text) => { this.setState({ atThree: text }) }}
                                ></TextInput>
                            </View>
                            <View style={ponsoffnStyle.blankTextView2}>
                                <TouchableOpacity onPress={() => this.getLocation()}>
                                    <Image style={ponsoffnStyle.loc_img} source={checkIn}></Image>
                                </TouchableOpacity>
                            </View>
                            <View style={ponsoffnStyle.blankTextView3}>
                                <TouchableOpacity onPress={() => this.prevLocation()}>
                                    <Image style={ponsoffnStyle.refr_img} source={prevsLocation}></Image></TouchableOpacity>
                            </View>
                        </View>

                        <View style={ponsoffnStyle.contrView}>
                            <Text style={{ color: '#7B7B7B', fontSize: 12, flex: 0.5 }}>CONTRARY TO*</Text>
                            <View>
                                <ModalDropdown
                                    dropdownStyle={{ width: '90%', height: 50, borderRadius: 0.5, shadowColor: 'black', shadowOpacity: 100, elevation: 20, }}
                                    dropdownTextStyle={{ fontSize: 17, color: 'black' }}
                                    textStyle={{ color: "black", fontSize: 17 }}
                                    animated={true}
                                    defaultIndex={0}
                                    defaultValue={Global_Attributes.PonLaws['parent_law'][0]}
                                    options={Global_Attributes.PonLaws['parent_law']}
                                    onSelect={(id) => { this.fetchLawsTitle(Global_Attributes.PonLaws['parent_law_id'][id]) }}
                                />
                                <Image source={Dropdownarrow} style={ponsoffnStyle.drpImgStyle} />
                            </View>

                        </View>
                        <LawsSearch PonOffence={true} navigation={this.props.navigation} />
                        {/* <CheckBox 
                            checked={this.state.speedingCb} 
                            style={{marginStart:30,marginTop:10}} 
                            rightText={"Speeding"} 
                            //checkBoxColor='#11246F'
                            onValueChange={()=> this.sppeedigCheckBoxChanged()} 
                            unCheckedBorderColor={'#11246F' }
                            checkedBackgroundColor={"#11246F"}
                            checkedBorderColor={"#11246F"} 
                            borderWidth={2}
                            checkMarkColor={'white'} 
                            checkMarkSize={18} 
                            animationType={'left'}
                            size={18}
                            rippleEffect={false}
                            label="Speeding"
                            labelStyle={{color:'#11246e'}}
                        ></CheckBox> */}


                        {/* {this.state.speedingCb ? <View style={{ flexDirection: 'row', height: 70, marginStart: 12, marginEnd: 12 }}>
                            <View style={{ flexDirection: 'column', width: '35%' }}>
                                <Text style={{ alignSelf: 'center', color: '#7B7B7B' }}>KM OVER</Text>
                                <Picker style={{ flex: 1 }}
                               selectedValue = {this.state.km_over}
                               onValueChange={(itemValue, itemIndex) =>
                                this.setState({km_over : itemValue})}
                                >
                                    <Picker.Item label='5' value='5'/>
                                    <Picker.Item label='10' value='10'/>
                                </Picker>
                            </View>
                            <View style={{ flexDirection: 'column', flex: 1 }}>
                                <View style={{ flexDirection: 'row', height: '30%' }}>
                                    <Text style={{ color: '#7B7B7B', alignSelf: 'center', flex: 1 }}>Schedule</Text>
                                    <Text style={{ color: '#7B7B7B', alignSelf: 'center', flex: 1 }}>Schedule</Text>
                                </View>
                                <View style={{ flexDirection: 'row', flex: 1 }}>
                                    <View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
                                        <RadioButton
                                            value="1"
                                            color="#11246F"
                                            status={
                                                this.state.schedule === '1' ? 'checked' : 'unchecked'
                                            }
                                            onPress={() => {
                                                this.setState({ schedule: '1' });
                                            }}
                                        />
                                       <Text style={{ alignSelf: 'center', color: '#11246F', fontSize: 12, }}>1</Text>
                                    </View>
                                    <View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
                                        <RadioButton
                                            value="2"
                                            color="#11246F"
                                            status={
                                                this.state.schedule === '2' ? 'checked' : 'unchecked'
                                            }
                                            onPress={() => this.setState({ schedule: '2' })}
                                        />
                                        <Text style={{ alignSelf: 'center', color: '#11246F', fontSize: 12 }}>2</Text>
                                    </View>
                                </View>
                            </View>
                        </View> : null} */}
                        {/* {this.state.schedule == '' && this.state.speedingCb ? <View style={{flexDirection:'row',alignItems:'center'}}>
                                    <RadioButton.Group >
                                        <View style={{flexDirection:'row'}}>
                                        <RadioButton
                                            value="fir"
                                            color="#11246F"
                                            status={
                                                this.state.schld2Rb === 'fir' ? 'checked' : 'unchecked'
                                            }
                                            onPress={() => {
                                                this.setState({ schld2Rb: 'fir' });
                                            }}
                                        />
                                        <Text style={{alignSelf:'center',color:'#11246F',fontSize:14}}>Community Safety Zone</Text>
                                        <RadioButton
                                            value="sec"
                                            color="#11246F"
                                            status={
                                                this.state.schld2Rb === 'sec' ? 'checked' : 'unchecked'
                                            }
                                            onPress={() => {
                                                this.setState({ schld2Rb: 'sec' });
                                            }}
                                        />
                                        <Text style={{color:'#11246F',fontSize:14}}>Construction Zone -{"\n"} Worker Present</Text>
                                        </View>
                                    </RadioButton.Group>          
                        </View> : null} */}
                        {/* {this.state.speedingCb ? <View style={{ flexDirection: 'row', height: 55, marginTop: 10, marginStart: 12, marginEnd: 12, bottom: 5 }}>
                            <TextInput style={{ flex: 1, backgroundColor: '#ffffff', fontSize: 12 }}
                                label='SPEED LIMIT*' underlineColor={'#000000'}></TextInput>
                            <TextInput style={{ flex: 1, backgroundColor: '#ffffff', marginLeft: 5, fontSize: 11 }}
                                label='CHARGED SPEED' underlineColor={'#000000'} ></TextInput>
                            <TextInput style={{ flex: 1, backgroundColor: '#ffffff', marginLeft: 5, fontSize: 12 }}
                                label='ACTUAL SPEED' underlineColor={'#000000'} ></TextInput>
                        </View> : null} */}
                        <View style={ponsoffnStyle.inputTextView}>
                            <View style={ponsoffnStyle.main_text_views}>
                                <TextInput style={ponsoffnStyle.inputTextStyleTwo}
                                    label='PLATE NUMBER' underlineColor={'#000000'}
                                    value={this.state.plateNumber}
                                    onChangeText={(text) => { this.setState({ plateNumber: text }) }}
                                ></TextInput>
                            </View>
                            <View style={ponsoffnStyle.main_text_views}>
                                <TextInput style={ponsoffnStyle.inputTextStyleTwo}
                                    label='JURIS' value='ON' underlineColor={'#000000'} ></TextInput>
                            </View>
                        </View>

                        <View style={ponsoffnStyle.inputTextcodeView}>
                            <TextInput style={ponsoffnStyle.inputTextStyle}
                                value={this.state.code}
                                onChangeText={(text) => { this.setState({ code: text }) }}
                                label='CODE' underlineColor={'#000000'}></TextInput>
                        </View>
                        {/* {this.state.didCommit != '' ?
                        <View  style={this.state.didCommit != '' ? ponstyle.actTitleFlatlist : null}>
                        <FlatList
                               nestedScrollEnabled={true}
                               maxHeight={250}
                               data={act_title}
                               style={{flex:1,}}
                               renderItem={({item}) => {
                                   return (
                                   <View style={{flex: 1, borderBottomWidth: 0.5,borderColor: 'black', marginRight:15,marginLeft:15}}>
                                   <TouchableOpacity
                                       onPress={()=>{this.setState({acttitlevalue:item,query:'',actnovalue:this.setAct(item)})}}>
                                   <Text style={ponstyle.itemText}>{item}</Text>
                                   </TouchableOpacity>
                                   </View>
                                   );
                               }}
                               keyExtractor={(item) => item}  
                            />
                            </View>
                            :
                            <View></View>
                           } */}

                        {/* <View style={ponstyle.autocompleteView}>
                            <Autocomplete
                                autoCorrect={false}
                                containerStyle={ponstyle.autocompletecontainer}
                                inputContainerStyle={ponstyle.autocompleteinnercontainer}
                                placeholder="DID COMMIT*"
                                placeholderTextColor='grey'
                                onChangeText={text => this.setState({didCommit:text,acttitlevalue:text})}
                                value={this.state.didCommit}
                                style={{fontSize:15}}
                            />
                            <Image 
                                source={require('../View/assets/search.png')}
                                style={ponstyle.searchIcon}
                            /> 
                            </View>
                             
                            {this.state.sect != '' ?
                            <View  style={this.state.sect != '' ? ponstyle.actTitleFlatlist : null}>
                             <FlatList
                                nestedScrollEnabled={true}
                                maxHeight={200}
                                data={act_no}
                                style={{flex:1,}}
                                renderItem={({item}) => {
                                    return (
                                        <View style={{flex: 1,borderBottomWidth: 0.5,borderColor: 'black', marginRight:15,marginLeft:15}}>
                                    <TouchableOpacity 
                                        onPress={()=>{this.setState({actnovalue:(item.match(/.*(?=\s:)/))[0],query1:'',acttitlevalue:this.setActNo(item)})}}>
                                    <Text style={ponstyle.itemText}>{item}</Text>
                                    </TouchableOpacity>
                                            <TouchableOpacity
                                                onPress={()=>this.lawDescription(item)}
                                                style={{flex:1,position:'absolute',right:0,}}
                                            >
                                                <Image source={Viewdetails} style={{height:35,width:35,tintColor:'red',alignSelf:'center'}}/>
                                        </TouchableOpacity>
                                    </View>
                                    
                                    );
                                }}
                             keyExtractor={(item) => item}
                             />
                             </View>
                            :
                            null
                            }
                            */}
                        {/* <View style={ponstyle.autocompleteView}>
                            <Autocomplete
                                autoCorrect={false}
                                containerStyle={ponstyle.autocompletecontainer}
                                inputContainerStyle={ponstyle.autocompleteinnercontainer}
                                placeholder="SECT*"
                                placeholderTextColor='grey'
                                onChangeText={text => this.setState({ sect: text,actnovalue:text })}
                                value={this.state.sect}
                                style={{fontSize:15}}
                            />
                              
                            <Image 
                                source={require('../View/assets/search.png')}
                                style={ponstyle.searchIcon}
                            /> 
                            </View> */}


                        <View style={ponsoffnStyle.secCheckboxView} >

                            <View style={{ flexDirection: 'column', flex: 1, marginTop: "5%" }}>

                                {/* <View style={{ flex:0.5, flexDirection: 'row' }}> */}
                                <Text style={ponsoffnStyle.cvorText}>CVOR</Text>
                                <View style={{ paddingLeft: "15%" }}>
                                    <CheckBox checked={this.state.cvor}
                                        // style={{ marginStart: 30, marginTop: 10 }}
                                        checkBoxColor={'#11246F'}
                                        onValueChange={() => this.CvorCheckBoxChanged()}
                                        checkedBackgroundColor={"#11246F"}
                                        checkedBorderColor='#11246F'
                                        borderWidth={2}
                                        unCheckedBorderColor={'#11246F'}
                                        checkMarkColor={'white'}
                                        checkMarkSize={18}
                                        animationType={'left'}
                                        size={18}
                                        rippleEffect={false}
                                        label="YES"
                                        labelStyle={{ color: '#11246F' }}></CheckBox>
                                    {/* <Text style={{ paddingTop: "8%", color: 'darkblue' }}>Yes</Text> */}
                                </View>
                            </View>
                            <View style={{ flexDirection: 'column', flex: 1, marginTop: "5%", }}>
                                <Text style={ponsoffnStyle.nscText}>NSC</Text>
                                <View style={{ marginLeft: "17%" }}>
                                    <CheckBox checked={this.state.nsc}
                                        style={{ marginStart: 30, marginTop: 10 }}
                                        checkBoxColor={'#11246F'}
                                        onValueChange={() => this.NscCheckBoxChanged()}
                                        checkedBackgroundColor={"#11246F"}
                                        checkedBorderColor='#11246F'
                                        borderWidth={2}
                                        unCheckedBorderColor={'#11246F'}
                                        checkMarkColor={'white'}
                                        checkMarkSize={18}
                                        animationType={'left'}
                                        size={18}
                                        rippleEffect={false}
                                        label="YES"
                                        labelStyle={{ color: '#11246F' }}></CheckBox>
                                    {/* <Text style={{ paddingTop: "8%", color: 'darkblue' }}>Yes</Text> */}
                                </View>
                            </View>
                            <View style={{ flexDirection: 'column', flex: 1, marginTop: "5%", }}>
                                <Text style={ponsoffnStyle.commrText}>COMMERCIAL</Text>
                                <View style={{ marginLeft: "15%" }}>
                                    <CheckBox checked={this.state.commercial}
                                        style={{ marginStart: 30, marginTop: 10 }}
                                        checkBoxColor={'#11246F'}
                                        onValueChange={() => this.commercialCheckBoxChanged()}
                                        checkedBackgroundColor={"#11246F"}
                                        checkedBorderColor='#11246F'
                                        borderWidth={2}
                                        unCheckedBorderColor={'#11246F'}
                                        checkMarkColor={'white'}
                                        checkMarkSize={18}
                                        animationType={'left'}
                                        size={18}
                                        rippleEffect={false}
                                        label="YES"
                                        labelStyle={{ color: '#11246F' }}></CheckBox>
                                    {/* <Text style={{ paddingTop: "8%", color: 'darkblue' }}>Yes</Text> */}
                                </View>
                            </View>
                        </View>
                        {this.state.cvor || this.state.nsc ?
                            <View style={ponsoffnStyle.inputTextcodeView}>
                                <TextInput style={ponsoffnStyle.inputTextStyle}
                                    value={this.state.covrNumer}
                                    onChangeText={(text) => { this.setState({ covrNumer: text }) }}
                                    label='CVOR/NSC Number*' underlineColor={'#000000'}></TextInput>
                            </View> : null}

                        <View style={ponsoffnStyle.fineBoxView}>
                            <View style={ponsoffnStyle.insidefineBoxView}>
                                <Text style={{ color: '#7B7B7B', fontSize: 12 }}>SET FINE OF*</Text>
                                <TextInput value={this.state.fine} mode='outlined' outlineColor='#11246F' selectionColor={"#7B7B7B"} style={ponsoffnStyle.boxstyle}></TextInput>
                            </View>
                            <View style={ponsoffnStyle.insidefineBoxView1}>
                                <Text style={{ color: '#7B7B7B', fontSize: 12 }}>TOTAL PAYABLE*</Text>
                                <TextInput value={this.state.payable} mode='outlined' outlineColor='#11246F' selectionColor={"#7B7B7B"} style={ponsoffnStyle.boxstyle}></TextInput>
                            </View>
                        </View>


                        <View style={ponsoffnStyle.tnCView}>
                            {/* <CheckBox style={{marginStart:10,flex:1}} rightText={'BY CHECKING THIS BOX, I ACKNOWLEDGE THAT I HAVE REVIEWED ALL 
                            THE INFORMATION CONTAINED WITHIN THIS DOCUMENT AND CONFIRM IT TO BE ACCURATE.'} checkBoxColor='#11246F'></CheckBox>
                         */}

                            <View style={{ marginTop: "-40%" }}>
                                <CheckBox
                                    style={{ marginTop: '5%' }}
                                    // textRight={'BY CHECKING THIS BOX, I ACKNOWLEDGE THAT I HAVE REVIEWED ALL THE INFORMATION CONTAINED WITHIN THIS DOCUMENT AND CONFIRM IT TO BE ACCURATE.'}
                                    checked={this.state.concent}
                                    onValueChange={() => this.checkBoxChanged()}
                                    checkedBackgroundColor={"#11246F"}
                                    checkedBorderColor={"#11246F"}
                                    borderWidth={2}
                                    checkMarkColor={'white'}
                                    unCheckedBorderColor={'#11246F'}
                                    checkMarkSize={18}
                                    animationType={'left'}
                                    size={18}
                                    rippleEffect={false}></CheckBox>
                            </View>
                            <Text style={ponsoffnStyle.tncText}>
                                BY CHECKING THIS BOX, I ACKNOWLEDGE THAT I HAVE REVIEWED ALL THE
                                INFORMATION CONTAINED WITHIN THIS DOCUMENT AND CONFIRM IT TO BE
                                ACCURATE.
                            </Text>
                        </View>

                        <View style={{ flexDirection: 'row', flex: 1, marginTop: "-10%" }}>
                            <Button mode='contained' style={ponsoffnStyle.backBtn}
                                onPress={() => { this.back() }}
                            >BACK</Button>

                            <Button mode='contained' style={ponsoffnStyle.nxtBtn}
                                onPress={() => { this.next() }}>NEXT</Button>
                        </View>
                    </View>
                </ScrollView>
                {keyboardStatus === 'Keyboard Hidden' ? <View style={ponsoffnStyle.bottomView}>
                    <DashboardFooter navigation={navigation} />
                </View> : null}
            </SafeAreaView>
        )


    }

}

// const ponstyle = StyleSheet.create({
//     mainView: {
//         backgroundColor: '#DEE6E1',
//         flex: 1
//     },

//     Scrollview: {
//         alignSelf:'center',
//             // marginTop:12,
//             // width:'95%',
//             margin:'3%',
//             marginBottom:'5%',
//             flex:0.8,

//             backgroundColor:'#FFFFFF',
//     },
//     bottomView:{ 
//         flex: 0.1
//     }
//     ,
//     locationView: {
//         flexDirection: 'row',
//     },
//     autocompleteView:{
//         marginTop:15,
//         width:wp("90%"),
//         borderBottomWidth:1,
//         marginLeft:15,
//         marginRight:15

//     },
//     autocompletecontainer:{
//         backgroundColor: '#ffffff',
//         borderColor: '#ffffff',
//         borderWidth: 0,
//     },
//     autocompleteinnercontainer:{
//         backgroundColor: '#ffffff',
//         borderColor: '#ffffff',
//         borderBottomWidth:1,
//         maxWidth:'85%',
//     },
//     searchIcon: {
//         width: 25,
//         height: 25,
//         tintColor: 'grey',
//         position:'absolute',
//         right:25
//     },
//     itemText: {
//         fontSize: 15,
//         fontWeight:'800',
//         marginVertical:10,
//         color:'black',
//         alignSelf:'stretch',
//         marginRight:25,
//       },
//       actTitleFlatlist:{
//         maxWidth:'100%',
//         borderRadius: 0.5,
//         shadowColor: 'black',
//         shadowOpacity: 100,
//         elevation: 10,
//         paddingTop:15,
//         paddingBottom:8
//       },
// })
